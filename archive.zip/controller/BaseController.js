sap.ui.define(["sap/ui/core/mvc/Controller"],function(n){return n.extend("com.rg.sd.osc.controller.BaseController",{onInit:function(){}})});
//# sourceMappingURL=BaseController.js.map