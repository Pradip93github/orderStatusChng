sap.ui.define(["com/rg/sd/osc/controller/BaseController"],function(o){return o.extend("com.rg.sd.osc.controller.App",{onInit:function(){}})});
//# sourceMappingURL=App.controller.js.map