sap.ui.define(['com/rg/sd/osc/controller/BaseController'],
    function(BaseController){
     return BaseController.extend("com.rg.sd.osc.controller.App",{
       onInit: function(){
        
       },
     });
});